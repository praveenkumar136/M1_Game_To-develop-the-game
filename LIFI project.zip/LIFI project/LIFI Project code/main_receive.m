function varargout = main_receive(varargin)
% MAIN_RECEIVE MATLAB code for main_receive.fig
%      MAIN_RECEIVE, by itself, creates a new MAIN_RECEIVE or raises the existing
%      singleton*.
%
%      H = MAIN_RECEIVE returns the handle to a new MAIN_RECEIVE or the handle to
%      the existing singleton*.
%
%      MAIN_RECEIVE('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in MAIN_RECEIVE.M with the given input arguments.
%
%      MAIN_RECEIVE('Property','Value',...) creates a new MAIN_RECEIVE or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before main_receive_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to main_receive_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help main_receive

% Last Modified by GUIDE v2.5 13-Jul-2021 23:34:28

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @main_receive_OpeningFcn, ...
                   'gui_OutputFcn',  @main_receive_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before main_receive is made visible.
function main_receive_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to main_receive (see VARARGIN)

% Choose default command line output for main_receive
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes main_receive wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = main_receive_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
load z1;
load y5;
load s1;

z2=[];
a=arduino('DEMO');

for i=1:(length(z1)*length(z1))
    
x=analogRead(a,5);
z2=[z2,x];

end

save('z2','z2');
z3=z2';

z4=reshape(z3,64,64);
z4=mod(z4,255);

axes(handles.axes1);
imshow(z4/255);


% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)

load z1;
load y5;
load s1;
Fs=8192;

y6=[];
a=arduino('DEMO');

for i=1:length(y5)
    
x=analogRead(a,5);
y6=[y6,x];

end

save('y6','y6');

axes(handles.axes2);
t=1:length(y5);
plot(t,y6);

sound(y6,Fs)


% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double


% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton6.
function pushbutton6_Callback(hObject, eventdata, handles)
load z1;
load y5;
load s1;

s2=[];
a=arduino('DEMO');

for i=1:length(s1)
    
x=analogRead(a,5);
s2=[s2,x];

end

save('s2','s2');
s3=char(s2);

set(handles.edit1,'String',s3);

% hObject    handle to pushbutton6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton7.
function pushbutton7_Callback(hObject, eventdata, handles)
delete(instrfind)
clc;
clear;
close all;
main_receive
% hObject    handle to pushbutton7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton8.
function pushbutton8_Callback(hObject, eventdata, handles)
clc;
clear;
close all;
% hObject    handle to pushbutton8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
